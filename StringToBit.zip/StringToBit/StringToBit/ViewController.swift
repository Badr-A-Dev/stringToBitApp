//
//  ViewController.swift
//  StringToBit
//
//  Created by badr on 24/02/1442 AH.
//

import UIKit

class ViewController: UIViewController {
    var sum : Int = 0
    
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var text: UILabel!
    
    @IBOutlet weak var Index0: UISegmentedControl!
    @IBOutlet weak var Index1: UISegmentedControl!
    @IBOutlet weak var Index2: UISegmentedControl!
    @IBOutlet weak var Index3: UISegmentedControl!
    @IBOutlet weak var Index4: UISegmentedControl!
    @IBOutlet weak var Index5: UISegmentedControl!
    @IBOutlet weak var Index6: UISegmentedControl!
    @IBOutlet weak var Index7: UISegmentedControl!
    


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        text.layer.borderWidth = 5
        text.layer.borderColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        text.text = "0"
    }
    @IBAction func checkField(_ sender: Any) {
        toggleCheck ()
    }
    
    func toggleCheck () {
        
   
    if "\(sum)" == textField.text{
        text.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
    }
    else{
        text.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    }
    }
    
    
    @IBAction func action0(_ sender: Any) {
        if Index0.selectedSegmentIndex == 0 {
            sum -= 1
        } else {
            sum += 1
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action1(_ sender: Any) {
        if Index1.selectedSegmentIndex == 0 {
            sum -= 2
        } else {
            sum += 2
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action2(_ sender: Any) {
        if Index2.selectedSegmentIndex == 0 {
            sum -= 4
        } else {
            sum += 4
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action63(_ sender: Any) {
        if Index3.selectedSegmentIndex == 0 {
            sum -= 8
        } else {
            sum += 8
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action4(_ sender: Any) {
        if Index4.selectedSegmentIndex == 0 {
            sum -= 16
        } else {
            sum += 16
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action5(_ sender: Any) {
        if Index5.selectedSegmentIndex == 0 {
            sum -= 32
        } else {
            sum += 32
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action6(_ sender: Any) {
        if Index6.selectedSegmentIndex == 0 {
            sum -= 64
        } else {
            sum += 64
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    @IBAction func action7(_ sender: Any) {
        if Index7.selectedSegmentIndex == 0 {
            sum -= 128
        } else {
            sum += 128
        }
        text.text =  "\(sum)"
        toggleCheck ()
    }
    
}

